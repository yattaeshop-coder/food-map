# 京都・東京 美食口袋地圖

直接上傳 GitHub 即可使用的靜態網站，所有資料已整合進 index.html，不需安裝套件、不需編譯，也不需要 API 金鑰。

## 網站功能

- 京都19家、東京12家，可切換城市。
- 搜尋店名、地區與餐點；依餐點類型篩選。
- Google Maps 店家連結及路線按鈕。
- 收藏保存在目前瀏覽器，不會同步至其他裝置。

## 用 GitHub 網頁發布

1. 解壓縮本檔案。
2. 登入 GitHub，建立一個新的 Public repository，例如 japan-food-map。
3. 在 repository 中選 Add file → Upload files，上傳 index.html（也可一起上傳 README.md 及 .nojekyll），再按 Commit changes。
4. 打開 Settings → Pages。
5. Source 選 Deploy from a branch。
6. Branch 選 main，資料夾選 /(root)，按 Save。
7. 等發布完成後，在同一頁按 Visit site，這就是網站連結。

注意：index.html 必須直接放在 repository 最上層，請勿只上傳 ZIP，或連同外層資料夾一起上傳。

也可以將 index.html 放入現有 GitHub Pages 網站的 food 子資料夾；屆時以現有網址加 /food/ 開啟。請避免覆蓋既有首頁。

## 資料

依提供的美食截圖整理，資料查核日期2026-10-31。31家之外的待確認／歇業店家未收錄。營業狀態請以店家最新資訊為準。

## 官方發布教學

https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
